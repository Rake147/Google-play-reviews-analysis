```python
from itertools import count
from nltk.util import pr
import pandas as pd
```


```python
data=pd.read_csv('C:/Users/Rakesh/Datasets/user_reviews.csv')
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>App</th>
      <th>Translated_Review</th>
      <th>Sentiment</th>
      <th>Sentiment_Polarity</th>
      <th>Sentiment_Subjectivity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10 Best Foods for You</td>
      <td>I like eat delicious food. That's I'm cooking ...</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.533333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10 Best Foods for You</td>
      <td>This help eating healthy exercise regular basis</td>
      <td>Positive</td>
      <td>0.25</td>
      <td>0.288462</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10 Best Foods for You</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10 Best Foods for You</td>
      <td>Works great especially going grocery store</td>
      <td>Positive</td>
      <td>0.40</td>
      <td>0.875000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10 Best Foods for You</td>
      <td>Best idea us</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.300000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.isnull().sum()
```




    App                           0
    Translated_Review         26868
    Sentiment                 26863
    Sentiment_Polarity        26863
    Sentiment_Subjectivity    26863
    dtype: int64




```python
data=data.dropna()
```


```python
data.isnull().sum()
```




    App                       0
    Translated_Review         0
    Sentiment                 0
    Sentiment_Polarity        0
    Sentiment_Subjectivity    0
    dtype: int64




```python
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sentiments = SentimentIntensityAnalyzer()
data['Positive']=[sentiments.polarity_scores(i)['pos'] for i in data['Translated_Review']]
data['Negative']=[sentiments.polarity_scores(i)['neg'] for i in data['Translated_Review']]
data['Neutral']=[sentiments.polarity_scores(i)['neu'] for i in data['Translated_Review']]
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>App</th>
      <th>Translated_Review</th>
      <th>Sentiment</th>
      <th>Sentiment_Polarity</th>
      <th>Sentiment_Subjectivity</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neutral</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10 Best Foods for You</td>
      <td>I like eat delicious food. That's I'm cooking ...</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.533333</td>
      <td>0.534</td>
      <td>0.0</td>
      <td>0.466</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10 Best Foods for You</td>
      <td>This help eating healthy exercise regular basis</td>
      <td>Positive</td>
      <td>0.25</td>
      <td>0.288462</td>
      <td>0.519</td>
      <td>0.0</td>
      <td>0.481</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10 Best Foods for You</td>
      <td>Works great especially going grocery store</td>
      <td>Positive</td>
      <td>0.40</td>
      <td>0.875000</td>
      <td>0.451</td>
      <td>0.0</td>
      <td>0.549</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10 Best Foods for You</td>
      <td>Best idea us</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.300000</td>
      <td>0.677</td>
      <td>0.0</td>
      <td>0.323</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10 Best Foods for You</td>
      <td>Best way</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.300000</td>
      <td>0.808</td>
      <td>0.0</td>
      <td>0.192</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns
plt.figure(figsize=(15,10))
sns.scatterplot(data['Sentiment_Polarity'], data['Sentiment_Subjectivity'], hue=data['Sentiment'], edgecolor='white', palette='twilight_shifted_r')
plt.title('Google Play Store Reviews Sentiment Analysis', fontsize=20)
plt.show()
```

    C:\Users\Rakesh\Downloads\Anaconda\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_7_1.png)
    



```python

```
